# -*- coding: utf-8 -*-

"""
jishaku.features
~~~~~~~~~~~~~~~~~

The namespace containing the Feature components that go into the final Jishaku cog class.

:copyright: (c) 2021 Devon (Gorialis) R
:license: MIT, see LICENSE for more details.

"""
