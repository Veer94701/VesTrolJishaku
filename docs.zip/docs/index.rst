.. jishaku documentation master file, created by
   sphinx-quickstart on Sat Apr 28 01:09:57 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to jishaku's documentation!
===================================

.. image:: /images/jishaku-keyart.png

jishaku is a debugging and utility extension for discord.py bots.

The documentation is split up into categories. Please see the index below.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   whatsnew
   cog
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
